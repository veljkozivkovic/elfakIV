
// LAB1View.cpp : implementation of the CLAB1View class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "LAB1.h"
#endif

#include "LAB1Doc.h"
#include "LAB1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLAB1View

IMPLEMENT_DYNCREATE(CLAB1View, CView)

BEGIN_MESSAGE_MAP(CLAB1View, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CLAB1View construction/destruction

CLAB1View::CLAB1View() noexcept
{
	// TODO: add construction code here
	this->keyPressed = false;
	this->gridSize = 25;
}

CLAB1View::~CLAB1View()
{
}

BOOL CLAB1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}



// CLAB1View drawing

void CLAB1View::DrawRegularPolygon(CDC* pDC, int cx, int cy, int r, int n, float rotAngle)
{
	//cx, cy - centar poligona
	//r - poluprecnik
	//n - broj stranica
	//rotAngle - ugao rotacije u stepenima

	//ugao izrazen u radijanima
	float angle = 2 * 3.14159265359 / n;

	//rotacija
	float rot = rotAngle * 3.14159265359 / 180;

	//niz tacaka poligona
	POINT* points = new POINT[n];

	for (int i = 0; i < n; i++)
	{
		points[i].x = cx + r * cos(angle * i + rot);
		points[i].y = cy + r * sin(angle * i + rot);
	}



	pDC->Polygon(points, n);


	


	delete[] points;
}

POINT CLAB1View::GetTriangleCenter(POINT points[3])
{
	POINT centar;

	centar.x = (points[0].x + points[1].x + points[2].x) / 3;
	centar.y = (points[0].y + points[1].y + points[2].y) / 3;

	return centar;
}

void CLAB1View::OnDraw(CDC* pDC)
{
	CLAB1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	POINT centar;

	COLORREF oldColor = pDC->SetBkColor(RGB(200, 200, 200));
	pDC->SetBkMode(OPAQUE);

	CRect rect;
	GetClientRect(&rect);
	pDC->FillSolidRect(&rect, pDC->GetBkColor());

	CPen yellowSmallerPen(PS_SOLID, 2, RGB(255, 255, 0));
	CPen yellowPen(PS_SOLID, 4, RGB(255, 255, 0));
	CPen* pOldPen = pDC->SelectObject(&yellowPen);

	//crveni kv
	CBrush redBrush(RGB(255, 0, 0));
	CBrush* pOldBrush = pDC->SelectObject(&redBrush);

	POINT crveniK[4] = { {25, 112}, {112, 200}, {112, 375}, {25,290} };

	pDC->Polygon(crveniK, 4);
	
	pDC->SelectObject(pOldBrush);
	redBrush.DeleteObject();

	//diag troug
	CBrush diagBrush(HS_FDIAGONAL, RGB(130, 172, 255));
	pOldBrush = pDC->SelectObject(&diagBrush);

	POINT diagT[3] = { {25, 290}, {25, 475}, {200, 475} };

	pDC->Polygon(diagT, 3);

	pOldPen = pDC->SelectObject(&yellowSmallerPen);
	centar = GetTriangleCenter(diagT);
	DrawRegularPolygon(pDC, centar.x, centar.y, 30, 6, 0);

	pDC->SelectObject(pOldBrush);
	diagBrush.DeleteObject();

	//narandz troug
	CBrush orangeBrush(RGB(255, 153, 51));
	pOldBrush = pDC->SelectObject(&orangeBrush);

	POINT orangeT[3] = { {112, 200}, {112, 375}, {200, 300} };

	pDC->Polygon(orangeT, 3);

	pOldPen = pDC->SelectObject(&yellowSmallerPen);
	centar = GetTriangleCenter(orangeT);
	DrawRegularPolygon(pDC, centar.x, centar.y, 18, 7, 0);
	pOldPen = pDC->SelectObject(&yellowPen);

	pDC->SelectObject(pOldBrush);
	orangeBrush.DeleteObject();



	//zut trougao
	CBrush yellowBrush(RGB(255, 255, 0));
	pOldBrush = pDC->SelectObject(&yellowBrush);

	POINT yeelowT[3] = { {112,200}, {295, 400}, {295, 25} };

	pDC->Polygon(yeelowT, 3);

	pDC->SelectObject(pOldBrush);
	yellowBrush.DeleteObject();

	//zeleni troug
	CBrush greenBrush(RGB(50, 205, 50));
	pOldBrush = pDC->SelectObject(&greenBrush);

	POINT greenT[3] = { {295, 400}, {200, 475}, {380, 475} };

	pDC->Polygon(greenT, 3);

	pOldPen = pDC->SelectObject(&yellowSmallerPen);
	centar = GetTriangleCenter(greenT);
	DrawRegularPolygon(pDC, centar.x, centar.y, 15, 8, 0);
	pOldPen = pDC->SelectObject(&yellowPen);

	pDC->SelectObject(pOldBrush);
	greenBrush.DeleteObject();

	//pink
	CBrush pinkBrush(RGB(255, 153, 204));
	pOldBrush = pDC->SelectObject(&pinkBrush);

	POINT pinkK[4] = { {112,375}, {200, 300}, {295, 400}, {200, 475} };

	pDC->Polygon(pinkK, 4);

	pDC->SelectObject(pOldBrush);
	pinkBrush.DeleteObject();
	//ljubicast troug
	CBrush purpBrush(RGB(153, 0, 205));
	pOldBrush = pDC->SelectObject(&purpBrush);

	POINT purpT[3] = { {295, 25}, {295, 400}, {475, 200} };

	pDC->Polygon(purpT, 3);


	pOldPen = pDC->SelectObject(&yellowSmallerPen);
	centar = GetTriangleCenter(purpT);
	DrawRegularPolygon(pDC, centar.x, centar.y, 35, 4, 90);
	pOldPen = pDC->SelectObject(&yellowPen);

	pDC->SelectObject(pOldBrush);
	purpBrush.DeleteObject();


	yellowPen.DeleteObject();
	yellowSmallerPen.DeleteObject();


	//GRID
	if (this->keyPressed)
	{

		CPen gridPen(PS_SOLID, 1, RGB(150, 150, 150)); // sto manje vrednosti tamnije je
		CPen* pOldPen = pDC->SelectObject(&gridPen);


		//CRect rect;
		//GetClientRect(&rect);
		//rect.Height() i rect.Width() su visina i sirina prozora


		// Po vertikali
		for (int x = 0; x <= 500; x += this->gridSize)
		{
			pDC->MoveTo(x, 0);
			pDC->LineTo(x, 500);
		}

		// herozi
		for (int y = 0; y <= 500; y += this->gridSize)
		{
			pDC->MoveTo(0, y);
			pDC->LineTo(500, y);
		}

		// OBAVEZNO BEEEE
		pDC->SelectObject(pOldPen);
		gridPen.DeleteObject();
	}
}


// CLAB1View printing

BOOL CLAB1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CLAB1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CLAB1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CLAB1View diagnostics

#ifdef _DEBUG
void CLAB1View::AssertValid() const
{
	CView::AssertValid();
}

void CLAB1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

void CLAB1View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == VK_SPACE)
	{
		this->keyPressed = !this->keyPressed;
		Invalidate(); // Ovo je potrebno da bi se prozor ponovo iscrtavao
	}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

CLAB1Doc* CLAB1View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLAB1Doc)));
	return (CLAB1Doc*)m_pDocument;
}
#endif //_DEBUG


// CLAB1View message handlers
