
// LAB1View.h : interface of the CLAB1View class
//

#pragma once


class CLAB1View : public CView
{
protected: // create from serialization only
	CLAB1View() noexcept;
	DECLARE_DYNCREATE(CLAB1View)

// Attributes
public:
	CLAB1Doc* GetDocument() const;
	bool keyPressed;
	int gridSize;

// Operations
public:
	void DrawRegularPolygon(CDC* pDC, int cx, int cy, int r, int n, float rotAngle);
	POINT GetTriangleCenter(POINT points[3]);
// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CLAB1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in LAB1View.cpp
inline CLAB1Doc* CLAB1View::GetDocument() const
   { return reinterpret_cast<CLAB1Doc*>(m_pDocument); }
#endif

