
// Lab3View.cpp : implementation of the CLab3View class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Lab3.h"
#endif

#include "Lab3Doc.h"
#include "Lab3View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLab3View

IMPLEMENT_DYNCREATE(CLab3View, CView)

BEGIN_MESSAGE_MAP(CLab3View, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CLab3View construction/destruction

CLab3View::CLab3View() noexcept
{
	// TODO: add construction code here
	this->gridSize = 25;
	this->drawGrid = true;
	this->pieces = new DImage * [9];
	this->rotAngle = -90;
	this->LoadPieces();

}

CLab3View::~CLab3View()
{
	if (pieces)
	{
		for (int i = 0; i < 9; i++)
		{
			delete pieces[i];
		}
		delete[] pieces;
	}
}

BOOL CLab3View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CLab3View drawing

void CLab3View::OnDraw(CDC* pDC)
{
	CLab3Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	CRect clientRect;
	GetClientRect(&clientRect);

	CDC* memDC = new CDC();
	memDC->CreateCompatibleDC(pDC);
	int oldMemGmMode = memDC->SetGraphicsMode(GM_ADVANCED);
	int oldPdcGmMode = pDC->SetGraphicsMode(GM_ADVANCED);

	CBitmap memBmp;
	memBmp.CreateCompatibleBitmap(pDC, clientRect.Width(), clientRect.Height());
	CBitmap* oldMemBmp = memDC->SelectObject(&memBmp);

	Draw(memDC);
	pDC->BitBlt(0, 0, clientRect.Width(), clientRect.Height(), memDC, 0, 0, SRCCOPY);

	memDC->SelectObject(oldMemBmp);
	memDC->SetGraphicsMode(oldMemGmMode);
	delete memDC;
	pDC->SetGraphicsMode(oldPdcGmMode);
}


// CLab3View printing

BOOL CLab3View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CLab3View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CLab3View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CLab3View::LoadPieces()
{
	char S[] = " .bmp";
	for (int i = 0; i < 9; i++)
	{
		S[0] = '1' + i;
		pieces[i] = new DImage();
		pieces[i]->Load(CString(S));
	}
}

void CLab3View::ToGray(CBitmap* bmp)
{
	BITMAP bm;
	bmp->GetBitmap(&bm);

	BYTE* bits = new BYTE[bm.bmWidthBytes * bm.bmHeight];
	bmp->GetBitmapBits(bm.bmWidthBytes * bm.bmHeight, bits);

	// izostavljam zelenu pozadinu, pazi u memoriji se cuva slika BGR 
	COLORREF bkColor = RGB(bits[2], bits[1], bits[0]); 

	for (int i = 0; i < bm.bmWidthBytes * bm.bmHeight; i += 4) {
		if (RGB(bits[i + 2], bits[i + 1], bits[i]) == bkColor) continue; //ne diras zelenu pozadinu
		BYTE greyColor = min(255, float(bits[i + 2] + bits[i + 1] + bits[i]) / 3 + 64); //prosta konverzija...
		bits[i] = bits[i + 1] = bits[i + 2] = greyColor; 
	}

	bmp->SetBitmapBits(bm.bmWidthBytes * bm.bmHeight, bits);
	delete[] bits;
}

void CLab3View::ToRGB(CBitmap* bmp, int RGBchannelID)
{
	BITMAP bm;
	bmp->GetBitmap(&bm);

	BYTE* bits = new BYTE[bm.bmWidthBytes * bm.bmHeight];
	bmp->GetBitmapBits(bm.bmWidthBytes * bm.bmHeight, bits);
	COLORREF bkColor = RGB(bits[2], bits[1], bits[0]);

	for (int i = 0; i < bm.bmWidthBytes * bm.bmHeight; i += 4) {
		if (RGB(bits[i + 2], bits[i + 1], bits[i]) == bkColor) continue;
		BYTE greyColor = min(255, float(bits[i + 2] + bits[i + 1] + bits[i]) / 3 + 64); // ako samo preslikam direktno Boju u Boju' mnogo se istice slika od drugih
		bits[i + 2] = RGBchannelID == 0 ? greyColor : 0;
		bits[i + 1] = RGBchannelID == 1 ? greyColor : 0;
		bits[i] = RGBchannelID == 2 ? greyColor : 0;
	}
	bmp->SetBitmapBits(bm.bmWidthBytes * bm.bmHeight, bits);

	delete[] bits;
}

void CLab3View::DrawPiece(CDC* pDC, DImage* img, BOOL toRGB, int RGBchannelID)
{
	CBitmap bmpImage, bmpMask;
	BITMAP bmp;
	img->GetBitmap()->GetBitmap(&bmp);

	bmpMask.CreateBitmap(bmp.bmWidth, bmp.bmHeight, 1, 1, NULL);
	bmpImage.CreateBitmap(bmp.bmWidth, bmp.bmHeight, 1, bmp.bmBitsPixel, NULL);

	CDC* srcDC = new CDC();
	CDC* dstDC = new CDC();
	srcDC->CreateCompatibleDC(pDC);
	dstDC->CreateCompatibleDC(pDC);
	CBitmap* oldSrcBmp = srcDC->SelectObject(&bmpImage);
	CBitmap* oldDstBmp = dstDC->SelectObject(&bmpMask);

	//crtam sliku gore levo u srcDC leva-top 0,0 desna-bottom izslike u dc koji stavis na pocetku
	img->Draw(srcDC, CRect(0, 0, bmp.bmWidth, bmp.bmHeight), CRect(0, 0, bmp.bmWidth, bmp.bmHeight));

	//bk color zelena stavis i stavis da je pozadinska
	COLORREF clrTopLeft = srcDC->GetPixel(0, 0);
	COLORREF oldSrcBk = srcDC->SetBkColor(clrTopLeft);

	//dstDC ce bude slika crna cela a okolo belo
	dstDC->BitBlt(0, 0, bmp.bmWidth, bmp.bmHeight, srcDC, 0, 0, SRCCOPY);


	// prednja boja je bela, pozadniska crna jer bela AND boja daje tu boju
	//crna AND bilo koja daje crnu
	COLORREF oldSrcFk = srcDC->SetTextColor(RGB(255, 255, 255));
	srcDC->SetBkColor(RGB(0, 0, 0));

	//src dc slika sa originalnim bojama i oko crno sve
	srcDC->BitBlt(0, 0, bmp.bmWidth, bmp.bmHeight, dstDC, 0, 0, SRCAND);

	if (toRGB) {
		ToRGB(srcDC->GetCurrentBitmap(), RGBchannelID);
	}
	else {
		ToGray(srcDC->GetCurrentBitmap());
	}

	//OR sa crnom ostaje ista boja
	Translate(pDC, -(float)img->Width() / 2, -(float)img->Height() / 2, false);
	pDC->BitBlt(0, 0, bmp.bmWidth, bmp.bmHeight, dstDC, 0, 0, SRCAND); //pdc pozadina postaje crna i ostaje senka slike
	pDC->BitBlt(0, 0, bmp.bmWidth, bmp.bmHeight, srcDC, 0, 0, SRCPAINT); //slika je tu a crna je okolo
	//Translate(pDC, (float)img->Width() / 2, (float)img->Height() / 2, false);

	srcDC->SetBkColor(oldSrcBk);
	srcDC->SetTextColor(oldSrcFk);
	srcDC->SelectObject(oldSrcBmp);
	dstDC->SelectObject(oldDstBmp);
	delete srcDC;
	delete dstDC;

}

void CLab3View::Translate(CDC* pDC, float dX, float dY, bool rightMultiply)
{
	XFORM xForm;
	xForm.eM11 = 1.0f;
	xForm.eM12 = 0.0f;
	xForm.eM21 = 0.0f;
	xForm.eM22 = 1.0f;
	xForm.eDx = dX;
	xForm.eDy = dY;
	pDC->ModifyWorldTransform(&xForm, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);

}

void CLab3View::Scale(CDC* pDC, float sX, float sY, bool rightMultiply)
{
	XFORM xForm;
	xForm.eM11 = sX;
	xForm.eM12 = 0.0f;
	xForm.eM21 = 0.0f;
	xForm.eM22 = sY;
	xForm.eDx = 0.0f;
	xForm.eDy = 0.0f;
	pDC->ModifyWorldTransform(&xForm, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);

}

void CLab3View::Rotate(CDC* pDC, float angle, bool rightMultiply)
{
	XFORM xForm;
	float rad = angle * (3.14159265f / 180.0f);
	xForm.eM11 = cos(rad);
	xForm.eM12 = sin(rad);
	xForm.eM21 = -sin(rad);
	xForm.eM22 = cos(rad);
	xForm.eDx = 0.0f;
	xForm.eDy = 0.0f;
	pDC->ModifyWorldTransform(&xForm, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);

}

void CLab3View::Mirror(CDC* pDC, bool mx, bool my, bool rightMultiply)
{
	XFORM xForm;
	xForm.eM11 = mx ? -1.0f : 1.0f;
	xForm.eM12 = 0.0f;
	xForm.eM21 = 0.0f;
	xForm.eM22 = my ? -1.0f : 1.0f;
	xForm.eDx = 0.0f;
	xForm.eDy = 0.0f;


	pDC->ModifyWorldTransform(&xForm, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);

}

void CLab3View::Draw(CDC* pDC)
{
	DrawBg(pDC); 
	DrawGrid(pDC);
	DrawPieces(pDC);
}

void CLab3View::DrawBg(CDC* pDC) // moram da postavim popunim belom bojom pozadinu jer ce ostati crna iz bitblt
{
	CBrush brush(RGB(255, 255, 255));

	CRect client;
	GetClientRect(&client);
	pDC->FillRect(client, &brush);

	brush.DeleteObject();
}

void CLab3View::DrawGrid(CDC* pDC)
{
	if (this->drawGrid)
	{

		CPen gridPen(PS_SOLID, 1, RGB(195, 230, 245)); // sto manje vrednosti tamnije je
		CPen* pOldPen = pDC->SelectObject(&gridPen);

		// Po vertikali
		for (int x = 0; x <= gridSize * 20; x += this->gridSize)
		{
			pDC->MoveTo(x, 0);
			pDC->LineTo(x, gridSize * 20);
		}

		// herozi
		for (int y = 0; y <= gridSize * 20; y += this->gridSize)
		{
			pDC->MoveTo(0, y);
			pDC->LineTo(gridSize * 20, y);
		}


		pDC->SelectObject(pOldPen);
		gridPen.DeleteObject();
	}
}

void CLab3View::DrawPieces(CDC* pDC)
{
	XFORM oldOldTransform;
	pDC->GetWorldTransform(&oldOldTransform);

	//ceo sistem rotiram u mom rotAngle
	Translate(pDC, -250, -250, true);
	Rotate(pDC, rotAngle, true);
	Translate(pDC, 250, 250, true);

	XFORM oldTransform;
	pDC->GetWorldTransform(&oldTransform);

	//gore desno
	Translate(pDC, pieces[0]->Width() / 2 + 25 * 10 + 14, pieces[0]->Height() / 2 - 22 , false);
	Rotate(pDC, -110, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[2]);
	pDC->SetWorldTransform(&oldTransform);

	
	

	// gore sredina
	Translate(pDC, pieces[1]->Width() / 2 + 5 * 25 - 12, pieces[1]->Height() / 2 +  25 - 51, false);
	Rotate(pDC, -81, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[1]);
	pDC->SetWorldTransform(&oldTransform);
	

	// gore levo
	Translate(pDC, pieces[2]->Width() / 2 - 25, pieces[2]->Height() / 2 - 25  - 10, false);
	Rotate(pDC, 56, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[0],1 ,0);
	pDC->SetWorldTransform(&oldTransform);

	// srednje levo PLAVI
	Translate(pDC, pieces[5]->Width() / 2 - 29, pieces[5]->Height() / 2 + 6 * 25 - 35, false);
	Rotate(pDC, 39, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[5]);
	pDC->SetWorldTransform(&oldTransform);

	// srednje srednje 
	Translate(pDC, pieces[1]->Width() / 2 + 5 * 25 , pieces[0]->Height() / 2 + 5 * 25 + 3, false);
	Rotate(pDC, 162, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[4]);
	pDC->SetWorldTransform(&oldTransform);

	// srednje desno
	Translate(pDC, pieces[0]->Width() / 2 + 25 * 10 + 18, pieces[0]->Height() / 2 + 5 * 25- 10, false);
	Rotate(pDC, 8, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[3]);
	pDC->SetWorldTransform(&oldTransform);
	
	

	// dole levo
	Translate(pDC, pieces[8]->Width() / 2 - 38 , pieces[8]->Height() / 2 + 11 * 25 - 3, false);
	Rotate(pDC, -75, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[8]);
	pDC->SetWorldTransform(&oldTransform);

	// dole srednje
	Translate(pDC, pieces[7]->Width() / 2 - 36 + 6 * 25, pieces[7]->Height() / 2 + 11 * 25 - 4, false);
	Rotate(pDC, -69, false);
	Mirror(pDC, true, false, false);
	DrawPiece(pDC, pieces[7]);
	pDC->SetWorldTransform(&oldTransform);

	// dole desno
	Translate(pDC, pieces[6]->Width() / 2 + 11 * 25 + 5, pieces[6]->Height() / 2 + 12 * 25 - 31, false);
	Rotate(pDC, -91, false);
	Mirror(pDC, false, true, false);
	DrawPiece(pDC, pieces[6]);
	pDC->SetWorldTransform(&oldTransform);

	


	

	pDC->SetWorldTransform(&oldOldTransform);
}

void CLab3View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFLags)
{
	switch (nChar)
	{
	case VK_SPACE:
		this->drawGrid = !this->drawGrid;
		break;

	case VK_LEFT:
		this->rotAngle -= 90;
		break;

	case VK_RIGHT:
		this->rotAngle += 90;
		break;
	}
	Invalidate();
	CView::OnKeyDown(nChar, nRepCnt, nFLags);
}


// CLab3View diagnostics

#ifdef _DEBUG
void CLab3View::AssertValid() const
{
	CView::AssertValid();
}

void CLab3View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CLab3Doc* CLab3View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLab3Doc)));
	return (CLab3Doc*)m_pDocument;
}
#endif //_DEBUG


// CLab3View message handlers
