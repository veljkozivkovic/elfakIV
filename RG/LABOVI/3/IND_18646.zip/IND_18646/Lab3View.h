#include "DImage.h"
// Lab3View.h : interface of the CLab3View class
//

#pragma once


class CLab3View : public CView
{
protected: // create from serialization only
	CLab3View() noexcept;
	DECLARE_DYNCREATE(CLab3View)

// Attributes
public:
	CLab3Doc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Custom
private:
	int gridSize;
	bool drawGrid;
	int rotAngle;
	DImage** pieces;

	// Ucitaj BMP komadice
	void LoadPieces();

	// Bojenje
	void ToGray(CBitmap* bmp);
	void ToRGB(CBitmap* bmp, int RGBchannelID);
	void DrawPiece(CDC* pDC, DImage* img, BOOL toRGB = false, int RGBchannelID = 0); //POGLEJ KAKO RADI, cekaj luku...

	// Transformations
	void Translate(CDC* pDC, float dX, float dY, bool rightMultiply);
	void Scale(CDC* pDC, float sX, float sY, bool rightMultiply);
	void Rotate(CDC* pDC, float angle, bool rightMultiply);
	void Mirror(CDC* pDC, bool mx, bool my, bool rightMultiply);

	void Draw(CDC* pDC);
	void DrawBg(CDC* pDC);
	void DrawGrid(CDC* pDC);
	void DrawPieces(CDC* pDC);

	// Drawing grid and rotation of system
	afx_msg void OnKeyDown(UINT nChar, UINT RepCnt, UINT nFLags);

// Implementation
public:
	virtual ~CLab3View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Lab3View.cpp
inline CLab3Doc* CLab3View::GetDocument() const
   { return reinterpret_cast<CLab3Doc*>(m_pDocument); }
#endif

